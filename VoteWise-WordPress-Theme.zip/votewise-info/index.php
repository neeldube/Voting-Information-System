<?php get_header(); ?>
<main id="main-content">
  <section class="page-hero"><div class="site-container"><p class="eyebrow">From the project</p><h1><?php echo is_home() ? esc_html( get_the_title( (int) get_option( 'page_for_posts' ) ) ) : esc_html( get_bloginfo( 'name' ) ); ?></h1><p>Project articles, learning notes and updates.</p></div></section>
  <section class="page-content-wrap"><div class="site-container"><div class="news-grid">
  <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
    <article class="news-card"><span class="news-date"><?php echo esc_html( get_the_date() ); ?></span><h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3><p><?php echo esc_html( get_the_excerpt() ); ?></p><a href="<?php the_permalink(); ?>">Read more →</a></article>
  <?php endwhile; else : ?><div class="empty-news">No posts have been published yet.</div><?php endif; ?>
  </div><div class="pagination"><?php the_posts_pagination(); ?></div></div></section>
</main>
<?php get_footer(); ?>
