<?php
/** Theme setup for VoteWise — Voting Information System. */
if ( ! defined( 'ABSPATH' ) ) { exit; }

define( 'VOTEWISE_INFO_VERSION', '1.0.0' );

function vi_theme_setup() {
    load_theme_textdomain( 'votewise-info', get_template_directory() . '/languages' );
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'automatic-feed-links' );
    add_theme_support( 'custom-logo', array( 'height' => 120, 'width' => 420, 'flex-height' => true, 'flex-width' => true ) );
    add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ) );
    register_nav_menus( array(
        'primary' => __( 'Header Navigation', 'votewise-info' ),
        'footer'  => __( 'Footer Links', 'votewise-info' ),
    ) );
}
add_action( 'after_setup_theme', 'vi_theme_setup' );

function vi_enqueue_assets() {
    wp_enqueue_style( 'votewise-info-style', get_stylesheet_uri(), array(), VOTEWISE_INFO_VERSION );
    wp_enqueue_script( 'votewise-info-menu', get_template_directory_uri() . '/assets/js/menu.js', array(), VOTEWISE_INFO_VERSION, true );
}
add_action( 'wp_enqueue_scripts', 'vi_enqueue_assets' );

function vi_default_pages() {
    return array(
        'home'                 => 'Home',
        'about-voting'         => 'About Voting',
        'elections'            => 'Elections',
        'candidates'           => 'Candidates',
        'political-parties'    => 'Political Parties',
        'voting-information'   => 'Voting Information',
        'polling-information'  => 'Polling Information',
        'results'              => 'Results',
        'news-notices'         => 'News & Notices',
        'faq'                  => 'FAQ',
        'contact-us'           => 'Contact Us',
        'about-us'             => 'About Us',
        'privacy-policy'       => 'Privacy Policy',
        'disclaimer'           => 'Disclaimer',
    );
}

function vi_page_id_for_slug( $slug ) {
    $page = get_page_by_path( $slug, OBJECT, 'page' );
    return $page ? (int) $page->ID : 0;
}

function vi_url( $slug ) {
    if ( 'home' === $slug ) {
        return home_url( '/' );
    }
    $id = vi_page_id_for_slug( $slug );
    return $id ? get_permalink( $id ) : home_url( '/' . trim( $slug, '/' ) . '/' );
}

function vi_icon( $name, $class = '' ) {
    $icons = array(
        'ballot' => '<rect x="5" y="4" width="14" height="16" rx="2"/><path d="M9 4V2h6v2M9 10l2 2 4-4M9 16h6"/>',
        'book' => '<path d="M4 5.5A2.5 2.5 0 0 1 6.5 3H20v16H6.5A2.5 2.5 0 0 0 4 21.5z"/><path d="M4 5.5v16M8 7h8M8 11h8"/>',
        'people' => '<path d="M16 21v-2a4 4 0 0 0-4-4H7a4 4 0 0 0-4 4v2M9.5 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8ZM20 8a3.5 3.5 0 0 1-2.5 3.35M17 15h1a3 3 0 0 1 3 3v3"/>',
        'map' => '<path d="m3 6 6-3 6 3 6-3v15l-6 3-6-3-6 3z"/><path d="M9 3v15M15 6v15"/>',
        'chart' => '<path d="M4 19V5M4 19h17"/><path d="m7 15 4-4 3 2 5-7"/>',
        'party' => '<path d="M12 3 4 20l8-4 8 4-8-17Z"/><path d="m12 3 1.2 8.5M4 20l8-8.5 8 8.5"/>',
        'shield' => '<path d="M12 22s8-4 8-11V5l-8-3-8 3v6c0 7 8 11 8 11Z"/><path d="m9 12 2 2 4-4"/>',
        'check' => '<path d="m5 12 4 4L19 6"/>',
        'external' => '<path d="M14 3h7v7M10 14 21 3"/><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/>',
        'search' => '<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 5 5"/>',
        'calendar' => '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 10h18"/>',
        'mail' => '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/>',
        'help' => '<circle cx="12" cy="12" r="10"/><path d="M9.1 9a3 3 0 0 1 5.8 1c0 2-3 3-3 3M12 17h.01"/>',
        'globe' => '<circle cx="12" cy="12" r="10"/><path d="M2 12h20M12 2a15 15 0 0 1 0 20M12 2a15 15 0 0 0 0 20"/>',
        'menu' => '<path d="M4 6h16M4 12h16M4 18h16"/>',
        'close' => '<path d="m6 6 12 12M18 6 6 18"/>',
    );
    $body = isset( $icons[$name] ) ? $icons[$name] : $icons['ballot'];
    return '<svg class="' . esc_attr( $class ) . '" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' . $body . '</svg>';
}

function vi_primary_fallback_menu() {
    echo '<ul class="menu">';
    echo '<li><a href="' . esc_url( home_url( '/' ) ) . '">Home</a></li>';
    foreach ( array( 'about-voting', 'elections', 'candidates', 'voting-information', 'polling-information', 'results', 'news-notices', 'faq', 'contact-us' ) as $slug ) {
        $id = vi_page_id_for_slug( $slug );
        if ( $id ) { echo '<li><a href="' . esc_url( get_permalink( $id ) ) . '">' . esc_html( get_the_title( $id ) ) . '</a></li>'; }
    }
    echo '</ul>';
}

function vi_create_menu_page_item( $menu_id, $slug, $parent_id = 0, $position = 0 ) {
    $page_id = vi_page_id_for_slug( $slug );
    if ( ! $page_id ) { return 0; }
    $item_id = wp_update_nav_menu_item( $menu_id, 0, array(
        'menu-item-title'      => get_the_title( $page_id ),
        'menu-item-object'     => 'page',
        'menu-item-object-id'  => $page_id,
        'menu-item-type'       => 'post_type',
        'menu-item-status'     => 'publish',
        'menu-item-parent-id'  => (int) $parent_id,
        'menu-item-position'   => (int) $position,
    ) );
    return is_wp_error( $item_id ) ? 0 : (int) $item_id;
}

function vi_create_menu_custom_item( $menu_id, $title, $url, $parent_id = 0, $position = 0 ) {
    $item_id = wp_update_nav_menu_item( $menu_id, 0, array(
        'menu-item-title' => $title,
        'menu-item-url' => $url,
        'menu-item-type' => 'custom',
        'menu-item-status' => 'publish',
        'menu-item-parent-id' => (int) $parent_id,
        'menu-item-position' => (int) $position,
    ) );
    return is_wp_error( $item_id ) ? 0 : (int) $item_id;
}

function vi_build_navigation() {
    $primary = wp_get_nav_menu_object( 'VoteWise Main Navigation' );
    if ( ! $primary ) { $created_primary = wp_create_nav_menu( 'VoteWise Main Navigation' ); if ( ! is_wp_error( $created_primary ) ) { $primary = wp_get_nav_menu_object( $created_primary ); } }
    if ( ! is_wp_error( $primary ) ) {
        $menu_id = (int) $primary->term_id;
        if ( empty( wp_get_nav_menu_items( $menu_id ) ) ) {
            vi_create_menu_page_item( $menu_id, 'home', 0, 1 );
            $learn = vi_create_menu_custom_item( $menu_id, 'Learn', '#', 0, 2 );
            foreach ( array( 'about-voting', 'voting-information', 'polling-information', 'faq' ) as $i => $slug ) { vi_create_menu_page_item( $menu_id, $slug, $learn, $i + 1 ); }
            $elections = vi_create_menu_custom_item( $menu_id, 'Explore Elections', '#', 0, 3 );
            foreach ( array( 'elections', 'candidates', 'political-parties' ) as $i => $slug ) { vi_create_menu_page_item( $menu_id, $slug, $elections, $i + 1 ); }
            vi_create_menu_page_item( $menu_id, 'results', 0, 4 );
            vi_create_menu_page_item( $menu_id, 'news-notices', 0, 5 );
            $about = vi_create_menu_custom_item( $menu_id, 'About', '#', 0, 6 );
            foreach ( array( 'about-us', 'privacy-policy', 'disclaimer' ) as $i => $slug ) { vi_create_menu_page_item( $menu_id, $slug, $about, $i + 1 ); }
            vi_create_menu_page_item( $menu_id, 'contact-us', 0, 7 );
        }
        $locations = get_theme_mod( 'nav_menu_locations', array() );
        $locations['primary'] = $menu_id;
        set_theme_mod( 'nav_menu_locations', $locations );
    }

    $footer = wp_get_nav_menu_object( 'VoteWise Footer Links' );
    if ( ! $footer ) { $created_footer = wp_create_nav_menu( 'VoteWise Footer Links' ); if ( ! is_wp_error( $created_footer ) ) { $footer = wp_get_nav_menu_object( $created_footer ); } }
    if ( ! is_wp_error( $footer ) ) {
        $footer_id = (int) $footer->term_id;
        if ( empty( wp_get_nav_menu_items( $footer_id ) ) ) {
            foreach ( array( 'about-us', 'contact-us', 'privacy-policy', 'disclaimer', 'faq' ) as $i => $slug ) { vi_create_menu_page_item( $footer_id, $slug, 0, $i + 1 ); }
        }
        $locations = get_theme_mod( 'nav_menu_locations', array() );
        $locations['footer'] = $footer_id;
        set_theme_mod( 'nav_menu_locations', $locations );
    }
}

function vi_setup_site_on_activation() {
    foreach ( vi_default_pages() as $slug => $title ) {
        $existing = get_page_by_path( $slug, OBJECT, 'page' );
        if ( ! $existing ) {
            wp_insert_post( array(
                'post_type' => 'page',
                'post_status' => 'publish',
                'post_title' => $title,
                'post_name' => $slug,
                'post_content' => '',
                'comment_status' => 'closed',
                'ping_status' => 'closed',
            ) );
        }
    }
    $home = vi_page_id_for_slug( 'home' );
    if ( $home ) {
        update_option( 'show_on_front', 'page' );
        update_option( 'page_on_front', $home );
    }
    vi_build_navigation();
}
add_action( 'after_switch_theme', 'vi_setup_site_on_activation' );

function vi_excerpt_length( $length ) { return 25; }
add_filter( 'excerpt_length', 'vi_excerpt_length', 999 );
function vi_excerpt_more( $more ) { return '…'; }
add_filter( 'excerpt_more', 'vi_excerpt_more' );

/** Render the curated page content for the starter pages created by this theme. */
function vi_render_page_body( $slug ) {
    switch ( $slug ) {
        case 'about-voting':
            ?>
            <div class="content-intro">Voting is one way people take part in public decision-making. In an election, eligible voters choose representatives or express a choice according to the rules for that election. Understanding the process makes it easier to participate thoughtfully.</div>
            <div class="content-grid-3">
              <article class="info-card"><span class="quick-icon"><?php echo vi_icon( 'people' ); ?></span><h3>Public participation</h3><p>Voting gives eligible people a way to express their preferences and participate in decisions about representation.</p></article>
              <article class="info-card"><span class="quick-icon"><?php echo vi_icon( 'book' ); ?></span><h3>Informed choices</h3><p>Learning about issues, candidates and party policies helps people assess information with care.</p></article>
              <article class="info-card"><span class="quick-icon"><?php echo vi_icon( 'shield' ); ?></span><h3>Fair participation</h3><p>Respectful discussion, reliable information and following official procedures support a fair process.</p></article>
            </div>
            <section class="content-section"><h2>What does voting involve?</h2><p>The precise process varies by country, election and local rules. In general, election authorities publish information about who may vote, how to register where registration is required, when voting takes place and how votes are counted.</p><p>Voters can prepare by checking official instructions early, learning about the choices on the ballot and confirming practical details from trustworthy sources.</p></section>
            <section class="content-section"><h2>Principles worth remembering</h2><ul><li><strong>Accuracy:</strong> verify facts before sharing them, especially dates, eligibility information and claims about candidates.</li><li><strong>Respect:</strong> people may hold different views; discuss public issues without harassment or personal attacks.</li><li><strong>Privacy:</strong> personal voting choices are private. Do not pressure others to disclose how they voted.</li><li><strong>Responsibility:</strong> use official sources for procedures and make independent, informed decisions.</li></ul></section>
            <div class="notice-box"><span class="notice-symbol">!</span><p><strong>Remember:</strong> this page explains general concepts. It does not determine anyone’s eligibility to vote. Use the official voter-services portal for current rules and personal voter information.</p></div>
            <p><a class="button button-primary" href="<?php echo esc_url( vi_url( 'voting-information' ) ); ?>">View voting resources <span class="button-arrow">→</span></a></p>
            <?php
            break;

        case 'elections':
            ?>
            <div class="content-intro">An election is an organised process through which voters choose representatives or make a decision. Different elections serve different levels of government and public organisations, so the rules and timetable can vary.</div>
            <div class="content-grid-3">
              <article class="info-card"><span class="quick-icon"><?php echo vi_icon( 'globe' ); ?></span><h3>National elections</h3><p>In India, national parliamentary elections determine the elected members of the Lok Sabha.</p></article>
              <article class="info-card"><span class="quick-icon"><?php echo vi_icon( 'map' ); ?></span><h3>State elections</h3><p>State legislative assembly elections determine elected representation within a state.</p></article>
              <article class="info-card"><span class="quick-icon"><?php echo vi_icon( 'people' ); ?></span><h3>Local elections</h3><p>Local-body elections relate to urban or rural local governance, under the applicable rules.</p></article>
            </div>
            <section class="content-section"><h2>How an election generally works</h2><ol><li><strong>Announcement:</strong> the responsible authority publishes the schedule and important instructions.</li><li><strong>Candidate nominations:</strong> eligible candidates submit required nomination documents, which are examined under the rules.</li><li><strong>Campaign period:</strong> candidates and parties communicate their ideas, subject to applicable election rules.</li><li><strong>Polling:</strong> eligible voters cast their vote using the method and procedure specified by the election authority.</li><li><strong>Counting and results:</strong> votes are counted and the responsible authority publishes official results.</li></ol></section>
            <section class="content-section"><h2>Where to verify election details</h2><p>Schedules, nomination deadlines, polling dates and results are election-specific. Do not rely on old posters, forwarded messages or unofficial social media posts for current details.</p><div class="link-cards"><a class="link-card" href="https://eci.gov.in/" target="_blank" rel="noopener noreferrer"><span class="link-card-icon"><?php echo vi_icon( 'globe' ); ?></span><span><b>Election Commission of India</b><small>Official announcements and resources ↗</small></span></a><a class="link-card" href="https://results.eci.gov.in/" target="_blank" rel="noopener noreferrer"><span class="link-card-icon"><?php echo vi_icon( 'chart' ); ?></span><span><b>Official election results</b><small>Results portal ↗</small></span></a></div></section>
            <?php
            break;

        case 'candidates':
            ?>
            <div class="content-intro">Candidates are people seeking election to a public role. This page does not endorse any candidate or provide a live candidate directory. It explains how to approach candidate information fairly and critically.</div>
            <section class="content-section"><h2>Questions to consider when reading about candidates</h2><div class="content-grid-2">
              <article class="info-card"><h3>Experience and public work</h3><p>Read verified background information and distinguish documented public work from opinion or promotional claims.</p></article>
              <article class="info-card"><h3>Policy priorities</h3><p>Look for clear plans, explanations and evidence. Compare proposals in context rather than relying on slogans alone.</p></article>
              <article class="info-card"><h3>Public statements</h3><p>Check the original source and date of a statement. Short clips or screenshots may leave out important context.</p></article>
              <article class="info-card"><h3>Disclosure information</h3><p>Where officially available, consult verified nomination and disclosure documents instead of unverified summaries.</p></article>
            </div></section>
            <section class="content-section"><h2>A neutral way to compare information</h2><ul><li>Use the same questions and standards for every candidate.</li><li>Separate confirmed facts, campaign promises, commentary and allegations.</li><li>Check publication dates and consult more than one credible source.</li><li>Be careful with edited images, forwarded messages and claims without evidence.</li><li>Make your own decision; this site does not recommend a candidate or party.</li></ul></section>
            <div class="notice-box"><span class="notice-symbol">!</span><p><strong>Information changes.</strong> Candidate lists and nomination status can vary by election and date. Refer to the responsible official election authority for current verified details.</p></div>
            <p><a class="button button-primary" href="https://eci.gov.in/" target="_blank" rel="noopener noreferrer">Visit the official ECI website <span class="button-arrow">↗</span></a></p>
            <?php
            break;

        case 'political-parties':
            ?>
            <div class="content-intro">Political parties bring together people who share political goals or policy priorities. Parties may select candidates, publish manifestos, organise campaigns and take part in legislative work. This page presents general information without favouring any party.</div>
            <div class="content-grid-3"><article class="info-card"><span class="quick-icon"><?php echo vi_icon( 'people' ); ?></span><h3>Represent ideas</h3><p>Parties organise viewpoints and offer policy approaches for voters to consider.</p></article><article class="info-card"><span class="quick-icon"><?php echo vi_icon( 'book' ); ?></span><h3>Publish manifestos</h3><p>Manifestos describe priorities and proposals. Read the full, dated document where possible.</p></article><article class="info-card"><span class="quick-icon"><?php echo vi_icon( 'chart' ); ?></span><h3>Public accountability</h3><p>Voters can assess policies, public statements and records using evidence and context.</p></article></div>
            <section class="content-section"><h2>How to read a party manifesto</h2><ul><li>Identify the issue the proposal aims to address.</li><li>Look for detail about funding, responsibilities, timing and implementation.</li><li>Compare commitments with official documents and credible reporting.</li><li>Check whether the manifesto is current and applies to the election you are studying.</li></ul></section>
            <section class="content-section"><h2>Keep your comparison fair</h2><p>Use the same criteria when reading about different parties. Avoid treating rumours, memes or campaign claims as independently verified facts. A balanced civic-information website explains how to evaluate information rather than telling people what political view to hold.</p></section>
            <?php
            break;

        case 'voting-information':
            ?>
            <div class="content-intro">Use this page as a starting point for voter-related information. If you are looking for registration, corrections, electoral-roll details or application status in India, the official Voters’ Services Portal is the most appropriate place to begin.</div>
            <div class="link-cards"><a class="link-card" href="https://voters.eci.gov.in/" target="_blank" rel="noopener noreferrer"><span class="link-card-icon"><?php echo vi_icon( 'people' ); ?></span><span><b>Voters’ Services Portal</b><small>Registration and voter-service guidance ↗</small></span></a><a class="link-card" href="https://electoralsearch.eci.gov.in/" target="_blank" rel="noopener noreferrer"><span class="link-card-icon"><?php echo vi_icon( 'search' ); ?></span><span><b>Search electoral-roll details</b><small>Use the official search portal ↗</small></span></a></div>
            <section class="content-section"><h2>Before relying on voter information</h2><ul><li>Check the official portal for the latest eligibility requirements and registration process.</li><li>Review the instructions for the relevant state, constituency and election.</li><li>Keep personal information private and enter it only on a genuine official service.</li><li>Use the portal’s own guidance to learn which documents or forms apply to your situation.</li><li>Keep any application reference information secure and use the official site to track status.</li></ul></section>
            <section class="content-section"><h2>Voter ID and registration are not the same question</h2><p>Possessing an identity document does not, by itself, mean that a person’s name is correctly included in the electoral roll for a particular election. Follow the current official guidance and check your electoral-roll details using the authorised service.</p></section>
            <div class="notice-box"><span class="notice-symbol">!</span><p><strong>Important:</strong> This student project cannot register a voter, verify an individual’s eligibility or make changes to official records. Rules and procedures can change; check the official portal for your personal circumstances.</p></div>
            <section class="content-section"><h2>Other official resources</h2><div class="link-cards"><a class="link-card" href="https://eci.gov.in/" target="_blank" rel="noopener noreferrer"><span class="link-card-icon"><?php echo vi_icon( 'globe' ); ?></span><span><b>Election Commission of India</b><small>Official website ↗</small></span></a><a class="link-card" href="https://electoralsearch.eci.gov.in/pollingstation" target="_blank" rel="noopener noreferrer"><span class="link-card-icon"><?php echo vi_icon( 'map' ); ?></span><span><b>Polling-station search</b><small>Official voter-services resource ↗</small></span></a></div></section>
            <?php
            break;

        case 'polling-information':
            ?>
            <div class="content-intro">Polling details are specific to the election and the voter’s registered details. Check the official source ahead of time rather than depending on an old message or an unverified map.</div>
            <section class="content-section"><h2>A practical preparation checklist</h2><div class="content-grid-2"><article class="info-card"><span class="quick-icon"><?php echo vi_icon( 'map' ); ?></span><h3>Confirm your polling location</h3><p>Use the official voter-services portal to check the relevant polling-station details before election day.</p></article><article class="info-card"><span class="quick-icon"><?php echo vi_icon( 'book' ); ?></span><h3>Read the latest instructions</h3><p>Check the current rules for identification, permitted items, accessibility and polling hours from official guidance.</p></article><article class="info-card"><span class="quick-icon"><?php echo vi_icon( 'calendar' ); ?></span><h3>Check the date and timing</h3><p>Polling schedules can differ by location and election. Rely on the official schedule for your area.</p></article><article class="info-card"><span class="quick-icon"><?php echo vi_icon( 'shield' ); ?></span><h3>Protect your privacy</h3><p>Never share an OTP, password or sensitive personal details with people claiming to offer unofficial voter help.</p></article></div></section>
            <section class="content-section"><h2>Useful official links</h2><div class="link-cards"><a class="link-card" href="https://electoralsearch.eci.gov.in/pollingstation" target="_blank" rel="noopener noreferrer"><span class="link-card-icon"><?php echo vi_icon( 'map' ); ?></span><span><b>Find polling-station information</b><small>Official ECI service ↗</small></span></a><a class="link-card" href="https://voters.eci.gov.in/" target="_blank" rel="noopener noreferrer"><span class="link-card-icon"><?php echo vi_icon( 'people' ); ?></span><span><b>Voters’ Services Portal</b><small>Voter records and service guidance ↗</small></span></a></div></section>
            <div class="notice-box"><span class="notice-symbol">!</span><p><strong>Do not rely on this website for the final polling instruction.</strong> Verify the polling location, date, hours and accepted documents with the official election authority for the election you plan to attend.</p></div>
            <?php
            break;

        case 'results':
            ?>
            <div class="content-intro">Election results should be taken from the responsible official election authority. This project does not calculate, verify or publish live results and should not be treated as the official record.</div>
            <div class="link-cards"><a class="link-card" href="https://results.eci.gov.in/" target="_blank" rel="noopener noreferrer"><span class="link-card-icon"><?php echo vi_icon( 'chart' ); ?></span><span><b>Election Commission results portal</b><small>View official election results and trends where published ↗</small></span></a><a class="link-card" href="https://eci.gov.in/" target="_blank" rel="noopener noreferrer"><span class="link-card-icon"><?php echo vi_icon( 'globe' ); ?></span><span><b>Election Commission of India</b><small>Official announcements and reports ↗</small></span></a></div>
            <section class="content-section"><h2>How to read results responsibly</h2><ul><li>Check the election name, constituency, date and the status of the information.</li><li>Distinguish trends or interim updates from final declared results.</li><li>Check the official authority’s wording and notes before quoting figures.</li><li>Use the relevant official report if you need historical figures for a school project.</li><li>Do not share screenshots without a source or enough context to identify the election.</li></ul></section>
            <div class="notice-box"><span class="notice-symbol">!</span><p><strong>No live result data is stored here.</strong> Use the official portal above for the latest available results. This website is educational and independent.</p></div>
            <?php
            break;

        case 'news-notices':
            ?>
            <div class="content-intro">This section can show project updates and learning notices published by the website administrator. For official election schedules, public advisories or results, always use the responsible election authority’s website.</div>
            <?php
            $notice_query = new WP_Query( array( 'post_type' => 'post', 'post_status' => 'publish', 'posts_per_page' => 6, 'ignore_sticky_posts' => true ) );
            if ( $notice_query->have_posts() ) :
                echo '<div class="news-grid">';
                while ( $notice_query->have_posts() ) : $notice_query->the_post();
                    echo '<article class="news-card"><span class="news-date">' . esc_html( get_the_date() ) . '</span><h3><a href="' . esc_url( get_permalink() ) . '">' . esc_html( get_the_title() ) . '</a></h3><p>' . esc_html( get_the_excerpt() ) . '</p><a href="' . esc_url( get_permalink() ) . '">Read notice →</a></article>';
                endwhile;
                echo '</div>';
                wp_reset_postdata();
            else : ?>
                <div class="empty-news"><strong>No project notices have been published yet.</strong><p style="margin-bottom:0">When you have a verified update to share, publish it in WordPress under <strong>Posts → Add New</strong>. Add the date and source, and avoid presenting unverified claims as facts.</p></div>
            <?php endif; ?>
            <section class="content-section"><h2>Official announcements</h2><p>For information that affects voters, go directly to the official source instead of waiting for a project notice.</p><div class="link-cards"><a class="link-card" href="https://eci.gov.in/" target="_blank" rel="noopener noreferrer"><span class="link-card-icon"><?php echo vi_icon( 'globe' ); ?></span><span><b>Election Commission of India</b><small>Official news and notices ↗</small></span></a><a class="link-card" href="https://voters.eci.gov.in/" target="_blank" rel="noopener noreferrer"><span class="link-card-icon"><?php echo vi_icon( 'book' ); ?></span><span><b>Voters’ Services Portal</b><small>Official voter-service updates ↗</small></span></a></div></section>
            <?php
            break;

        case 'faq':
            ?>
            <div class="content-intro">Here are answers to common questions about this website and general voting concepts. Procedures differ between elections and may change, so use official sources for personal instructions.</div>
            <div class="faq-list">
              <details class="faq-item"><summary>What is the purpose of this website?</summary><p>It is a student-friendly educational guide to voting, elections, candidates, political parties, polling information and official resources.</p></details>
              <details class="faq-item"><summary>Is this an official Election Commission website?</summary><p>No. It is independent and not affiliated with or endorsed by the Election Commission of India or any government organisation.</p></details>
              <details class="faq-item"><summary>Can I register to vote through this project?</summary><p>No. This website does not submit registrations or change official records. Use the official Voters’ Services Portal for applicable services.</p></details>
              <details class="faq-item"><summary>Where can I search for my name in the electoral roll?</summary><p>Use the official electoral-roll search portal. This website does not access or store your personal voter record.</p></details>
              <details class="faq-item"><summary>Does the website show real-time election results?</summary><p>No. For official declared results and updates, visit the Election Commission’s results portal.</p></details>
              <details class="faq-item"><summary>How do I find polling-station details?</summary><p>Check the official voter-services portal and follow the current instructions for your registered details and relevant election.</p></details>
              <details class="faq-item"><summary>Can I use content for a school project?</summary><p>You may use the explanations as a starting point. Check facts against reliable sources and cite the original official source for changing or specific information.</p></details>
              <details class="faq-item"><summary>What should I do if I see a doubtful claim?</summary><p>Check the date, original source and independent evidence. Avoid reposting claims that cannot be verified.</p></details>
            </div>
            <section class="content-section"><h2>Official portals</h2><div class="link-cards"><a class="link-card" href="https://voters.eci.gov.in/" target="_blank" rel="noopener noreferrer"><span class="link-card-icon"><?php echo vi_icon( 'people' ); ?></span><span><b>Voters’ Services Portal</b><small>Voter services ↗</small></span></a><a class="link-card" href="https://results.eci.gov.in/" target="_blank" rel="noopener noreferrer"><span class="link-card-icon"><?php echo vi_icon( 'chart' ); ?></span><span><b>Official results</b><small>Results portal ↗</small></span></a></div></section>
            <?php
            break;

        case 'contact-us':
            ?>
            <div class="content-intro">This is an educational website project. For website-related feedback, use a project contact channel approved by the site owner or school supervisor.</div>
            <div class="content-grid-2"><article class="contact-card"><span class="quick-icon"><?php echo vi_icon( 'mail' ); ?></span><h2 style="margin:0 0 8px;font-size:20px">Website feedback</h2><p>Suggestions, broken links and source corrections are welcome. If you publish this site publicly, add a project-specific contact email or a properly configured contact form here.</p><p><strong>Privacy tip:</strong> avoid publishing personal contact details without permission. Do not send passwords, one-time codes or sensitive identity information to this educational project.</p></article>
            <article class="contact-card"><span class="quick-icon"><?php echo vi_icon( 'shield' ); ?></span><h2 style="margin:0 0 8px;font-size:20px">Need official election help?</h2><p>This project cannot resolve voter registration, polling-location or election-result questions. Use the official service for current assistance.</p><p><a class="button button-primary" href="https://voters.eci.gov.in/" target="_blank" rel="noopener noreferrer">Open official voter services <span class="button-arrow">↗</span></a></p></article></div>
            <div class="notice-box"><span class="notice-symbol">!</span><p>For official voter services, enter personal details only on the genuine official portal. This project does not register voters or access personal voter records.</p></div>
            <?php
            break;

        case 'about-us':
            ?>
            <div class="content-intro">The Voting Information System is a student-focused project designed to organise basic information about voting and elections in a simple, accessible format.</div>
            <div class="content-grid-3"><article class="info-card"><span class="quick-icon"><?php echo vi_icon( 'book' ); ?></span><h3>Education first</h3><p>We explain general concepts in plain language so learners can build a foundation.</p></article><article class="info-card"><span class="quick-icon"><?php echo vi_icon( 'shield' ); ?></span><h3>Source awareness</h3><p>We direct visitors to official sources when current procedures or results are needed.</p></article><article class="info-card"><span class="quick-icon"><?php echo vi_icon( 'people' ); ?></span><h3>Neutral learning</h3><p>We aim to explain how to evaluate information without endorsing a candidate or political party.</p></article></div>
            <section class="content-section"><h2>What this project does</h2><p>It introduces election concepts, explains how to find voter-service resources, and provides pages for candidates, parties, polling information and results. It does not register voters, verify personal details or publish live election results.</p><h2>Our approach</h2><p>We aim for clarity, accessibility, respectful civic learning and careful use of sources. Because procedures can change, visitors should confirm current details through the responsible official election authority.</p></section>
            <?php
            break;

        case 'privacy-policy':
            ?>
            <div class="notice-box"><span class="notice-symbol">i</span><p><strong>Starter privacy notice:</strong> Review and update this page before publishing publicly, especially if you add analytics, a contact form, user accounts, embedded content or other data collection features.</p></div>
            <section class="content-section"><h2>Information on this website</h2><p>This starter theme does not create voter accounts, collect voter-registration details or provide an online voting system. It displays educational information and links to external official resources.</p><h2>Contact information</h2><p>If you contact the website administrator by email, the information in your message may be received and handled through the email service used by the administrator. Avoid sending passwords, one-time codes or sensitive identity documents to this project.</p><h2>External websites</h2><p>Links to official portals and other external services open websites managed by their respective operators. Their privacy practices and terms apply when you visit them. Review the destination carefully before entering personal information.</p><h2>Cookies and technical services</h2><p>WordPress, the active hosting environment and any plugins added later may use cookies or process technical information. The site owner should review the active configuration and update this notice to match the actual site before public deployment.</p><h2>Updates to this notice</h2><p>This page is a project starter, not legal advice or a guarantee of compliance. Update it to accurately describe the website’s final settings, contact methods, and any data collection or retention.</p></section>
            <?php
            break;

        case 'disclaimer':
            ?>
            <div class="notice-box"><span class="notice-symbol">!</span><p><strong>Independent educational project.</strong> This website is not an official Election Commission of India or government website, and it is not affiliated with or endorsed by those organisations.</p></div>
            <section class="content-section"><h2>Educational purpose</h2><p>Content is provided to support general learning about voting and elections. It is not personal legal advice and does not determine a person’s eligibility, registration status or polling arrangements.</p><h2>Accuracy and changes</h2><p>Election laws, eligibility requirements, procedures, schedules and results may change and can vary by election. We do not guarantee that every page reflects the latest official information. Confirm current details using the relevant official authority.</p><h2>Official links</h2><p>External links are provided as a convenience for learning and verification. Linked websites are operated by their respective owners; inclusion of a link does not mean that this project controls or represents that organisation.</p><h2>No live voting or results service</h2><p>This site does not collect ballots, register voters, change official records, verify candidates or publish live election results. Use the proper official service for these tasks.</p><h2>Political neutrality</h2><p>The project is intended to explain concepts and encourage informed, respectful learning. It does not endorse candidates, parties or political positions.</p></section>
            <?php
            break;

        default:
            if ( trim( get_the_content() ) ) { the_content(); }
            else { echo '<p class="content-intro">Explore this section of the Voting Information System using the navigation menu above.</p>'; }
            break;
    }
}
