(function () {
  'use strict';
  document.addEventListener('DOMContentLoaded', function () {
    var toggle = document.querySelector('.menu-toggle');
    var nav = document.querySelector('.site-nav');
    if (!toggle || !nav) return;
    toggle.addEventListener('click', function () {
      var open = toggle.getAttribute('aria-expanded') === 'true';
      toggle.setAttribute('aria-expanded', open ? 'false' : 'true');
      toggle.setAttribute('aria-label', open ? 'Open navigation menu' : 'Close navigation menu');
      nav.classList.toggle('is-open', !open);
      var svg = toggle.querySelector('svg');
      if (svg) {
        svg.innerHTML = open
          ? '<path d="M4 6h16M4 12h16M4 18h16"/>'
          : '<path d="m6 6 12 12M18 6 6 18"/>';
      }
    });
    nav.addEventListener('click', function (event) {
      var link = event.target.closest('a');
      if (!link) return;
      if (window.matchMedia('(max-width: 880px)').matches && link.getAttribute('href') !== '#') {
        nav.classList.remove('is-open');
        toggle.setAttribute('aria-expanded', 'false');
        toggle.setAttribute('aria-label', 'Open navigation menu');
        var svg = toggle.querySelector('svg');
        if (svg) svg.innerHTML = '<path d="M4 6h16M4 12h16M4 18h16"/>';
      }
    });
  });
})();
