<?php get_header(); ?>
<main id="main-content">
<?php while ( have_posts() ) : the_post(); ?>
  <article class="article-content"><div class="breadcrumbs"><a href="<?php echo esc_url( home_url( '/' ) ); ?>">Home</a><span>/</span><a href="<?php echo esc_url( vi_url( 'news-notices' ) ); ?>">News &amp; Notices</a><span>/</span><span><?php the_title(); ?></span></div><h1><?php the_title(); ?></h1><div class="entry-meta">Published <?php echo esc_html( get_the_date() ); ?><?php if ( get_the_author() ) { echo ' · By ' . esc_html( get_the_author() ); } ?></div><?php the_content(); ?><?php wp_link_pages(); ?><p><a class="button button-light" href="<?php echo esc_url( vi_url( 'news-notices' ) ); ?>">← Back to News &amp; Notices</a></p></article>
<?php endwhile; ?>
</main>
<?php get_footer(); ?>
