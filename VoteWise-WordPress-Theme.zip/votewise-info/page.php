<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
while ( have_posts() ) : the_post();
    $slug = get_post_field( 'post_name', get_the_ID() );
    $descriptions = array(
        'about-voting' => 'Discover what voting means, why it matters, and how informed participation supports a healthy democracy.',
        'elections' => 'A clear introduction to election types, the election process and the roles of voters and election authorities.',
        'candidates' => 'Learn how to find and evaluate candidate information thoughtfully, fairly and from credible sources.',
        'political-parties' => 'Understand the role political parties play, how manifestos work and how to compare policy information.',
        'voting-information' => 'A practical guide to finding current voter registration, eligibility and electoral-roll information through official resources.',
        'polling-information' => 'Prepare for polling day and learn how to confirm your polling location and current voting instructions.',
        'results' => 'Find the official results portal and learn why declared results should always be verified at their source.',
        'news-notices' => 'Project notices and learning updates. For election schedules and public announcements, check official sources.',
        'faq' => 'Answers to common questions about voting, elections, voter services and this educational project.',
        'contact-us' => 'Questions or suggestions about this student project? Find the website contact details below.',
        'about-us' => 'Learn about the purpose of this Voting Information System and the principles behind its content.',
        'privacy-policy' => 'An overview of privacy considerations for this educational website. Update this page if you add data collection tools.',
        'disclaimer' => 'Important context about the purpose, scope and limits of the information shared on this website.',
    );
    $description = isset( $descriptions[$slug] ) ? $descriptions[$slug] : get_bloginfo( 'description' );
    ?>
    <main id="main-content">
      <section class="page-hero"><div class="site-container"><div class="breadcrumbs"><a href="<?php echo esc_url( home_url( '/' ) ); ?>">Home</a><span>/</span><span><?php the_title(); ?></span></div><p class="eyebrow">Voting Information System</p><h1><?php the_title(); ?></h1><p><?php echo esc_html( $description ); ?></p></div></section>
      <section class="page-content-wrap"><div class="site-container"><div class="page-content">
        <?php vi_render_page_body( $slug ); ?>
      </div></div></section>
    </main>
    <?php
endwhile;
get_footer();
