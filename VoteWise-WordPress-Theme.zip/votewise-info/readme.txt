VoteWise — Voting Information System
Version: 1.0.0

WHAT THIS THEME DOES
- Provides a responsive, professionally styled educational Voting Information System website.
- Uses a custom homepage with a hero section, quick links, learning cards, official links, FAQs and a project notices area.
- When activated, creates any missing project pages and sets the Home page as the homepage.
- Creates and assigns a header navigation menu and footer links automatically.
- Keeps existing WordPress pages and posts in the database; it does not delete them.
- Uses no paid plugins, no external font dependency, and no image dependency.

INSTALLATION
1. Sign into WordPress as an administrator.
2. Open Appearance > Themes > Add New Theme > Upload Theme.
3. Upload the VoteWise-WordPress-Theme.zip file and select Install Now.
4. Select Activate.
5. Open the website homepage (for a local XAMPP site, usually http://localhost/wordpress/).

IMPORTANT
This is an independent educational project, not an official Election Commission of India or government website. It does not register voters, collect ballots, verify personal voter records or publish live election results. Official links are provided for current services and information.

EDITING
The built-in theme templates render the starter content for the project pages. Use WordPress Posts > Add New to publish project news and notices; published posts show on the homepage and News & Notices page. Theme activation sets Home as the front page and assigns the theme's menus. Existing pages/posts are not deleted.

To switch back, go to Appearance > Themes and activate the previous theme (for example, Kadence). WordPress pages and posts remain saved.
