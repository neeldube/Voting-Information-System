<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<footer class="site-footer">
  <div class="site-container footer-main">
    <div class="footer-brand">
      <a class="site-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>">
        <span class="brand-mark"><?php echo vi_icon( 'ballot' ); ?></span>
        <span class="brand-copy"><span class="brand-name"><?php bloginfo( 'name' ); ?></span><span class="brand-tagline">Learn · Participate · Understand</span></span>
      </a>
      <p>A student-friendly guide to elections, voting, candidates and polling information. Built to help people learn and find reliable official resources.</p>
    </div>
    <div class="footer-column"><h3>Explore</h3><ul>
      <li><a href="<?php echo esc_url( vi_url( 'about-voting' ) ); ?>">About Voting</a></li>
      <li><a href="<?php echo esc_url( vi_url( 'elections' ) ); ?>">Elections</a></li>
      <li><a href="<?php echo esc_url( vi_url( 'candidates' ) ); ?>">Candidates</a></li>
      <li><a href="<?php echo esc_url( vi_url( 'political-parties' ) ); ?>">Political Parties</a></li>
    </ul></div>
    <div class="footer-column"><h3>Helpful pages</h3><ul>
      <li><a href="<?php echo esc_url( vi_url( 'voting-information' ) ); ?>">Voting Information</a></li>
      <li><a href="<?php echo esc_url( vi_url( 'polling-information' ) ); ?>">Polling Information</a></li>
      <li><a href="<?php echo esc_url( vi_url( 'results' ) ); ?>">Results</a></li>
      <li><a href="<?php echo esc_url( vi_url( 'news-notices' ) ); ?>">News &amp; Notices</a></li>
    </ul></div>
    <div class="footer-column"><h3>Official source</h3><div class="footer-source-box"><p>For actual voter services, registration guidance and verified election updates, check the Election Commission of India’s official website.</p><a href="https://eci.gov.in/" target="_blank" rel="noopener noreferrer">Visit eci.gov.in ↗</a></div></div>
  </div>
  <div class="footer-bottom"><div class="site-container footer-bottom-inner"><p>© <?php echo esc_html( date_i18n( 'Y' ) ); ?> <?php bloginfo( 'name' ); ?>. Educational project.</p><div class="footer-links-container"><?php wp_nav_menu( array( 'theme_location' => 'footer', 'container' => false, 'menu_class' => 'footer-inline-menu', 'fallback_cb' => false, 'depth' => 1 ) ); ?></div></div></div>
  <div class="site-container"><p class="disclaimer-line">This website is an independent educational project and is not affiliated with or endorsed by the Election Commission of India or any government body. Election information and procedures can change. Always verify current rules, schedules and results through official sources.</p></div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
