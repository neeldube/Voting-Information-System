<?php get_header(); ?>
<main id="main-content">
  <section class="hero">
    <div class="site-container hero-grid">
      <div class="hero-content">
        <p class="eyebrow">Your guide to informed participation</p>
        <h1>Understand your vote. <span class="highlight">Understand your voice.</span></h1>
        <p class="hero-copy">Explore elections, candidates, political parties and polling basics in one clear, student-friendly place. Learn the process and find trusted official resources when you need them.</p>
        <div class="hero-actions">
          <a class="button button-primary" href="<?php echo esc_url( vi_url( 'voting-information' ) ); ?>">Start with voting info <span class="button-arrow">→</span></a>
          <a class="button button-light" href="<?php echo esc_url( vi_url( 'elections' ) ); ?>">Explore elections</a>
        </div>
        <div class="hero-note"><span class="tiny-check">✓</span><span>Clear explanations · Responsible learning · Official links where it matters</span></div>
      </div>
      <div class="hero-art" aria-label="Illustration of a ballot checklist" role="img">
        <div class="art-orbit"></div>
        <div class="float-pill float-one"><span class="float-icon"><?php echo vi_icon( 'book' ); ?></span><span><b>Learn the process</b><small>Simple, useful explainers</small></span></div>
        <div class="ballot-card">
          <div class="ballot-card-top"><span class="ballot-stamp"><?php echo vi_icon( 'ballot' ); ?></span><span class="card-chip">Civic knowledge</span></div>
          <h3>Voting, made clearer.</h3><p>A quick guide to being prepared and informed.</p>
          <div class="ballot-row"><span class="ballot-box"><?php echo vi_icon( 'check' ); ?></span><span class="ballot-line"><b>Know the basics</b><span>Understand how elections work</span></span></div>
          <div class="ballot-row"><span class="ballot-box"><?php echo vi_icon( 'check' ); ?></span><span class="ballot-line"><b>Check official details</b><span>Use trusted election resources</span></span></div>
          <div class="ballot-row"><span class="ballot-box"><?php echo vi_icon( 'check' ); ?></span><span class="ballot-line"><b>Make informed choices</b><span>Compare information thoughtfully</span></span></div>
        </div>
        <div class="float-pill float-two"><span class="float-icon"><?php echo vi_icon( 'shield' ); ?></span><span><b>Information first</b><small>Independent learning project</small></span></div>
      </div>
    </div>
  </section>

  <section class="section section-white">
    <div class="site-container">
      <div class="section-head"><div><p class="eyebrow">Find what you need</p><h2>Explore voting information</h2><p>Jump straight to the topic you’re looking for, without the complicated wording.</p></div><a class="section-link" href="<?php echo esc_url( vi_url( 'about-voting' ) ); ?>">Discover the basics <span class="button-arrow">→</span></a></div>
      <div class="quick-grid">
        <a class="quick-card" href="<?php echo esc_url( vi_url( 'elections' ) ); ?>"><span class="quick-arrow">↗</span><span class="quick-icon"><?php echo vi_icon( 'calendar' ); ?></span><h3>Elections</h3><p>Learn about election types and the general election process.</p></a>
        <a class="quick-card" href="<?php echo esc_url( vi_url( 'candidates' ) ); ?>"><span class="quick-arrow">↗</span><span class="quick-icon"><?php echo vi_icon( 'people' ); ?></span><h3>Candidates</h3><p>Understand candidate information and how to compare it.</p></a>
        <a class="quick-card" href="<?php echo esc_url( vi_url( 'political-parties' ) ); ?>"><span class="quick-arrow">↗</span><span class="quick-icon"><?php echo vi_icon( 'party' ); ?></span><h3>Political parties</h3><p>Explore party roles, manifestos and public policies.</p></a>
        <a class="quick-card" href="<?php echo esc_url( vi_url( 'polling-information' ) ); ?>"><span class="quick-arrow">↗</span><span class="quick-icon"><?php echo vi_icon( 'map' ); ?></span><h3>Polling information</h3><p>Prepare for polling day and find official booth details.</p></a>
      </div>
    </div>
  </section>

  <section class="section section-soft">
    <div class="site-container">
      <div class="section-head centered"><p class="eyebrow">A simple place to begin</p><h2>Build your civic knowledge, step by step</h2><p>Whether you are learning for a project or getting ready to participate, start with the basics and verify important details with official sources.</p></div>
      <div class="feature-grid">
        <article class="feature-card"><span class="feature-number">01</span><h3>Learn how voting works</h3><p>Understand the purpose of voting, different elections and the responsibilities involved in democratic participation.</p><a href="<?php echo esc_url( vi_url( 'about-voting' ) ); ?>">Read about voting →</a></article>
        <article class="feature-card"><span class="feature-number">02</span><h3>Compare information carefully</h3><p>Read candidate profiles, party manifestos and policy information critically. Look for context and credible sources.</p><a href="<?php echo esc_url( vi_url( 'candidates' ) ); ?>">Explore candidates →</a></article>
        <article class="feature-card"><span class="feature-number">03</span><h3>Check practical details</h3><p>For current registration rules, polling locations and results, go directly to the official election portals.</p><a href="<?php echo esc_url( vi_url( 'voting-information' ) ); ?>">View voting information →</a></article>
      </div>
    </div>
  </section>

  <section class="section">
    <div class="site-container">
      <div class="section-head"><div><p class="eyebrow">Know the journey</p><h2>From learning to being prepared</h2><p>General steps that help you find reliable information before an election.</p></div></div>
      <div class="steps-grid">
        <div class="step-item"><h3>Understand eligibility</h3><p>Read the current eligibility and registration guidance published by the official election authority.</p></div>
        <div class="step-item"><h3>Verify your details</h3><p>Use official services to check voter registration, electoral-roll details and polling information.</p></div>
        <div class="step-item"><h3>Stay informed</h3><p>Follow official announcements and compare candidate and party information using credible sources.</p></div>
      </div>
    </div>
  </section>

  <section class="section section-white">
    <div class="site-container"><div class="official-panel">
      <div><p class="eyebrow">Official links</p><h2>For real election services, go to the source.</h2><p>This website explains concepts. Official portals should be used for current voter services, polling details and declared results.</p></div>
      <div class="official-links">
        <a class="official-link" href="https://voters.eci.gov.in/" target="_blank" rel="noopener noreferrer"><span class="external-icon"><?php echo vi_icon( 'people' ); ?></span><span><b>Voters’ Services Portal</b><small>Registration and voter services ↗</small></span></a>
        <a class="official-link" href="https://electoralsearch.eci.gov.in/" target="_blank" rel="noopener noreferrer"><span class="external-icon"><?php echo vi_icon( 'search' ); ?></span><span><b>Search electoral roll</b><small>Check official voter details ↗</small></span></a>
        <a class="official-link" href="https://results.eci.gov.in/" target="_blank" rel="noopener noreferrer"><span class="external-icon"><?php echo vi_icon( 'chart' ); ?></span><span><b>Election results</b><small>Official results portal ↗</small></span></a>
        <a class="official-link" href="https://eci.gov.in/" target="_blank" rel="noopener noreferrer"><span class="external-icon"><?php echo vi_icon( 'globe' ); ?></span><span><b>Election Commission of India</b><small>Official website and updates ↗</small></span></a>
      </div>
    </div></div>
  </section>

  <section class="section">
    <div class="site-container">
      <div class="section-head"><div><p class="eyebrow">From the project</p><h2>News &amp; notices</h2><p>Project updates appear here after the site administrator publishes a post. Official election announcements should always be verified at their source.</p></div><a class="section-link" href="<?php echo esc_url( vi_url( 'news-notices' ) ); ?>">View all notices <span class="button-arrow">→</span></a></div>
      <?php $home_news = new WP_Query( array( 'post_type' => 'post', 'post_status' => 'publish', 'posts_per_page' => 3, 'ignore_sticky_posts' => true ) ); ?>
      <?php if ( $home_news->have_posts() ) : ?><div class="news-grid"><?php while ( $home_news->have_posts() ) : $home_news->the_post(); ?><article class="news-card"><span class="news-date"><?php echo esc_html( get_the_date() ); ?></span><h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3><p><?php echo esc_html( get_the_excerpt() ); ?></p><a href="<?php the_permalink(); ?>">Read update →</a></article><?php endwhile; ?></div><?php wp_reset_postdata(); ?><?php else : ?><div class="empty-news"><strong>No project notices have been published yet.</strong> When you have a verified update, publish it from WordPress Dashboard → Posts → Add New. For official election updates, visit <a href="https://eci.gov.in/" target="_blank" rel="noopener noreferrer">eci.gov.in ↗</a>.</div><?php endif; ?>
    </div>
  </section>

  <section class="section section-soft">
    <div class="site-container">
      <div class="section-head centered"><p class="eyebrow">Frequently asked</p><h2>Quick answers to get you started</h2><p>These are general educational explanations. Always check official sources for current procedures.</p></div>
      <div class="faq-list">
        <details class="faq-item"><summary>What is voting?</summary><p>Voting is a way for eligible people to express a choice in an election or other decision-making process. In elections, votes help determine who will represent the public.</p></details>
        <details class="faq-item"><summary>Where can I check voter details?</summary><p>Use the Election Commission of India’s Voters’ Services Portal and electoral-roll search. This project does not store or verify personal voter records.</p></details>
        <details class="faq-item"><summary>Does this website publish live results?</summary><p>No. This is an educational project, not a live results service. Use the official ECI results portal for declared results and updates.</p></details>
        <details class="faq-item"><summary>Is this an official government website?</summary><p>No. It is an independent learning project and is not affiliated with any election authority or government department.</p></details>
      </div>
      <p style="text-align:center;margin:24px 0 0"><a class="section-link" href="<?php echo esc_url( vi_url( 'faq' ) ); ?>">Visit all FAQs →</a></p>
    </div>
  </section>

  <section class="cta-band"><div class="site-container cta-inner"><div><h2>Make learning about voting easier.</h2><p>Start with a topic, ask thoughtful questions, and verify current details through trusted official resources.</p></div><a class="button button-primary" href="<?php echo esc_url( vi_url( 'voting-information' ) ); ?>">Explore voting information <span class="button-arrow">→</span></a></div></section>
</main>
<?php get_footer(); ?>
