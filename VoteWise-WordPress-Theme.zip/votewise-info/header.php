<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="skip-link" href="#main-content">Skip to content</a>
<div class="top-note"><div class="site-container top-note-inner"><span class="note-dot"></span><span>An independent learning project · Not an official Election Commission website</span></div></div>
<header class="site-header">
  <div class="site-container header-inner">
    <a class="site-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?> — Home">
      <span class="brand-mark"><?php echo vi_icon( 'ballot' ); ?></span>
      <span class="brand-copy"><span class="brand-name"><?php bloginfo( 'name' ); ?></span><span class="brand-tagline">Learn · Participate · Understand</span></span>
    </a>
    <button class="menu-toggle" type="button" aria-expanded="false" aria-controls="primary-navigation" aria-label="Open navigation menu">
      <?php echo vi_icon( 'menu' ); ?>
    </button>
    <nav class="site-nav" id="primary-navigation" aria-label="Main navigation">
      <?php wp_nav_menu( array( 'theme_location' => 'primary', 'container' => false, 'menu_class' => 'menu', 'fallback_cb' => 'vi_primary_fallback_menu', 'depth' => 2 ) ); ?>
    </nav>
    <div class="nav-cta"><a class="button button-primary" href="https://voters.eci.gov.in/" target="_blank" rel="noopener noreferrer">Official voter services <span class="button-arrow">↗</span></a></div>
  </div>
</header>
